package ejercicio1;

public class Principal {
	
	public static void main(String[] args) {

	    Empleado[] empleados = new Empleado[5];
	    
	    //carga de empleado 1
	    empleados[0] = new Empleado("Adriel",22);
	   
	    //carga de empleado 2
	    empleados[1] = new Empleado();
	    empleados[1].setNombre("Dalila");
	    empleados[1].setEdad(19);
	    
	    
	    //carga de empleado 3
	    empleados[2] = new Empleado("Ivan",22);
	    
	    //carga de empleado 4
	    empleados[3] = new Empleado();
	    
	    //carga de empleado 5
	    empleados[4] = new Empleado();
	    
	    //toString de los 5 empleados
	    for (Empleado emp : empleados) {
	    	System.out.println(emp.toString());
	    }
	    
	    //toString del proximo ID
	    System.out.println(" El proximo ID sera: "+Empleado.devuelveProxId());
	    
	    
	  }
}
