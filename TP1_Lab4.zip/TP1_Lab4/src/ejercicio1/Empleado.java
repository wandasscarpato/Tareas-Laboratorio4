package ejercicio1;

public class Empleado {
		//atributos
		private int id;
		private String nombre;
		private int edad;
		
		static int cant= 999;
		
		//Contructores
		public Empleado() {
			
			  cant++;
			  this.id = cant;
			  this.nombre = "Sin nombre";
			  this.edad = 99;
			}
		
		public Empleado(String nombre,int edad) {
			
			cant++;
			this.id = cant;
			this.nombre = nombre;
			this.edad = edad;
			
			  
		}
		
		//METODOS
		
		public static int devuelveProxId()
		{
			return cant+1;
			
		}
		
		//getters setters
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public int getEdad() {
			return edad;
		}
		public void setEdad(int edad) {
			this.edad = edad;
		}

		//ToString()
		@Override
		public String toString() {
			return " Empleado " + nombre + ", Edad: " + edad + " Legajo: " + id ;
		}
		
}
