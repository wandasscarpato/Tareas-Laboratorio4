package ejercicio2;

public class ProductosRefrigerados extends Producto {
	
	private int codigoOrganismoDeSupervision;

	//constructores
	public ProductosRefrigerados() {
		super();
		this.codigoOrganismoDeSupervision = 0;
	}
	
	public ProductosRefrigerados(String fechaDeCaducidad, int numeroDeLote, int codigoOrganismoDeSupervision) {
		super(fechaDeCaducidad,numeroDeLote);
		this.codigoOrganismoDeSupervision = codigoOrganismoDeSupervision;
	}
	//getters and setters
	public int getCodigoOrganismoDeSupervision() {
		return codigoOrganismoDeSupervision;
	}


	public void setCodigoOrganismoDeSupervision(int codigoOrganismoDeSupervision) {
		this.codigoOrganismoDeSupervision = codigoOrganismoDeSupervision;
	}


	@Override
	public String toString() {
		return "Productos Refrigerados. Codigo Alimentario= " + codigoOrganismoDeSupervision + super.toString() ;
	} 

	
}
