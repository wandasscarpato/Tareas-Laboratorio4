package ejercicio2;

public class ProductosCongelados extends Producto {
	
	private int temperaturaRecomendada;

	//constructores
		public ProductosCongelados() {
			super();
			this.temperaturaRecomendada = 0;
		}
		
		public ProductosCongelados(String fechaDeCaducidad, int numeroDeLote, int temperaturaRecomendada) {
			super(fechaDeCaducidad, numeroDeLote);
			this.temperaturaRecomendada = temperaturaRecomendada;
		}
		//getters setters

	public int getTemperaturaRecomendada() {
		return temperaturaRecomendada;
	}

	public void setTemperaturaRecomendada(int temperaturaRecomendada) {
		this.temperaturaRecomendada = temperaturaRecomendada;
	}
	
	//toString

	@Override
	public String toString() {
		return "Productos Congelados. Fecha De Caducidad= " + getFechaCaducidad() +", numero De Lote=" + getNlote() +", temperatura Recomendada=" + temperaturaRecomendada;
	}

	
}
