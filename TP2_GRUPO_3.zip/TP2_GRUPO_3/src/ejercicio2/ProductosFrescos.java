package ejercicio2;

public class ProductosFrescos extends Producto{
	
	private String fechaDeEnvasado;
	private String paisDeOrigen;
	
	//constructores
	public ProductosFrescos() {
		super();
		this.fechaDeEnvasado = "ninguna";
		this.paisDeOrigen = "ninguna";

	}
	
	public ProductosFrescos(String fechaDeCaducidad, int numeroDeLote, String fechaDeEnvasado, String paisDeOrigen) {
		super(fechaDeCaducidad,numeroDeLote);
		this.fechaDeEnvasado = fechaDeEnvasado;
		this.paisDeOrigen = paisDeOrigen;

	}
	public String getFechaEnvasado() {
		return fechaDeEnvasado;
	}
	public void setFechaEnvasado(String fechaEnvasado) {
		fechaDeEnvasado = fechaEnvasado;
	}
	public String getPaisOrigen() {
		return paisDeOrigen;
	}
	public void setPaisOrigen(String paisOrigen) {
		paisDeOrigen = paisOrigen;
	}
	
	@Override
	public String toString() {
		return "Productos Frescos. Fecha de Envasado= " + fechaDeEnvasado  + ", Pais de Origen= " + paisDeOrigen + super.toString();
	}
	
	
	
	

}
