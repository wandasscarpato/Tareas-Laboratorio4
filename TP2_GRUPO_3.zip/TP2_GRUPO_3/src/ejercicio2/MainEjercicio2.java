package ejercicio2;

public class MainEjercicio2 {

	public static void main(String[] args) {
		ProductosRefrigerados pr= new ProductosRefrigerados("25 de abril del 2021",10,5);
		ProductosCongelados pc= new ProductosCongelados("12 de enero del 2022",12,25);
		ProductosFrescos pf= new ProductosFrescos("24 de marzo de 2021", 12, "20 de marzo del 2021", "Argentina");
		
		System.out.println(pr);
		System.out.println(pc);
		System.out.println(pf);
	}

}
