package ejercicio2;

public class Producto {
	private String FechaCaducidad;
	private int Nlote;
	
	//constructores
		public Producto() {
			this.FechaCaducidad = "0";
			this.Nlote = 0;
		}
		public Producto(String fechaDeCaducidad, int numeroDeLote) {
			this.FechaCaducidad = fechaDeCaducidad;
			this.Nlote = numeroDeLote;
		}
	
		//getters and setters
	
		public int getNlote() {
			return Nlote;
		}
		public void setNlote(int nlote) {
			Nlote = nlote;
		}
		public void setFechaCaducidad(String fechaCaducidad) {
			FechaCaducidad = fechaCaducidad;
		}

		public String getFechaCaducidad() {
			return FechaCaducidad;
		}
		
	@Override
	public String toString() {
		return " Producto Fecha de Caducidad= " + FechaCaducidad + ", Numero de Lote= " + Nlote;
	}
	

}
