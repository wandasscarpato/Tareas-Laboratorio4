package ejercicio3;

public class Polideportivo extends Edificio{
	public String nombre;

	
	
	public Polideportivo() {
		super();
		this.nombre="no aclarado";
	}


	public Polideportivo(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	
}
