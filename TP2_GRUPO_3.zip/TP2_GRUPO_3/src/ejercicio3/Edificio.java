package ejercicio3;

public class Edificio {
	private double superficie;
	private int cantidadOficinas;
	
	//constructor
	
	public Edificio() {
		this.superficie = 0;
		this.cantidadOficinas= 0;
		
	}

	public Edificio(double superficie, int cantidadOficinas) {
		this.superficie = superficie;
		this.cantidadOficinas = cantidadOficinas;
	}


	//getters y setters
	public double getSuperficie() {
		return superficie;
	}



	public void setSuperficie(double superficie) {
		this.superficie = superficie;
	}



	public int getCantidadOficinas() {
		return cantidadOficinas;
	}



	public void setCantidadOficinas(int cantidadOficinas) {
		this.cantidadOficinas = cantidadOficinas;
	}


	//toString
	@Override
	public String toString() {
		return "Edificio. superficie= " + superficie + ", cantidadOficinas=" + cantidadOficinas;
	}
	
	
}
