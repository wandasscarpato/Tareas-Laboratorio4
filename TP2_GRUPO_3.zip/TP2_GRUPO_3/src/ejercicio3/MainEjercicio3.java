package ejercicio3;

public class MainEjercicio3 {
public static void main(String[] args) {
	
}
}
