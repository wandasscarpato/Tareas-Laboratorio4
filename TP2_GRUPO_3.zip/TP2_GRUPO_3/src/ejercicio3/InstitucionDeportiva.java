package ejercicio3;

public class InstitucionDeportiva {
	private int tipoDeInstalacion;
	
	//constructores
	private InstitucionDeportiva(){
		this.tipoDeInstalacion=1;
	}
	private InstitucionDeportiva(int tipoDeInstalacion) {
		this.tipoDeInstalacion=tipoDeInstalacion;
	}
	//get/set
	public int getTipoDeInstalacion() {
		return tipoDeInstalacion;
	}
	public void setTipoDeInstalacion(int tipoDeInstalacion) {
		this.tipoDeInstalacion = tipoDeInstalacion;
	}
	
	//toString
	@Override
	public String toString() {
		return "InstitucionDeportiva. TipoDeInstalacion= " + tipoDeInstalacion;
	}
	
	
	
}
