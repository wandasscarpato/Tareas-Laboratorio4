package ejercicio1;

import java.util.Iterator;
import java.util.TreeSet;

public class mainEjercicio1_b {

	public static void main(String[] args) {
		
		//Declaracion de Treeset
		TreeSet<Profesor> listaProfesores = new TreeSet<Profesor>();
		
		//Carga de profesores
		Profesor profesor1 = new Profesor("Programacion I", 7, "Marcos", 31);
		Profesor profesor2 = new Profesor("Programacion II", 12, "Natalia", 38);
		Profesor profesor3 = new Profesor("Programacion III", 17, "Mariana", 45);
		Profesor profesor4 = new Profesor("Programacion IV", 9, "Gabriela", 36);
		Profesor profesor5 = new Profesor("Programacion V", 20, "Carlos", 52);
		Profesor profesor6 = new Profesor("Matematica",10,"Cristian",30);
		Profesor profesor7 = new Profesor("Matematica",10,"Cristian",30);
		
		//Carga de Treeset
		listaProfesores.add(profesor1);
		listaProfesores.add(profesor2);
		listaProfesores.add(profesor3);
		listaProfesores.add(profesor4);
		listaProfesores.add(profesor5);
		
		//Muestra de Iterator
		Iterator<Profesor> it = listaProfesores.iterator();
		while(it.hasNext()) {
			Profesor profesor = it.next();
			it.remove();
			System.out.println(profesor.toString());
		}
		
		if(profesor6.equals(profesor7)){
			System.out.println("Es el mismo profesor");
		}
		else {
			System.out.println("NO es le mismo profesor");
		}
		
		
	}

}
