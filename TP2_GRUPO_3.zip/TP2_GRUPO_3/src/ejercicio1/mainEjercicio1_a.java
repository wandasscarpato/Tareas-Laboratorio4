package ejercicio1;

import java.util.ArrayList;
import java.util.ListIterator;

public class mainEjercicio1_a {

	public static void main(String[] args) {
		
		
		//carga de profesores
		Profesor profesor1 = new Profesor("Matematica", 7, "Marcos", 31);
		Profesor profesor2 = new Profesor("Quimica", 12, "Natalia", 38);
		Profesor profesor3 = new Profesor("Fisica", 17, "Mariana", 45);
		Profesor profesor4 = new Profesor("Estadistica", 9, "Gabriela", 36);
		Profesor profesor5 = new Profesor("Programacion", 20, "Carlos", 52);
		
		//declaraci�n de ArrayList y carga
		ArrayList<Profesor> listaProfesores = new ArrayList<Profesor>();
		listaProfesores.add(profesor1);
		listaProfesores.add(profesor2);
		listaProfesores.add(profesor3);
		listaProfesores.add(profesor4);
		listaProfesores.add(profesor5);
		
		//muestra con Iterator
		ListIterator<Profesor> it = listaProfesores.listIterator();
		while (it.hasNext()) {
		Profesor profesor = it.next();
		it.remove();
		System.out.println(profesor.toString());
		}		
	}
}
