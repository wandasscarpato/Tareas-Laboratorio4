package ejercicio1;

public class Profesor extends Empleado  implements Comparable<Profesor>{
	 //Atributos
	 private String cargo;
	 private int antiguedadDocente;
	
	 //Contructores
	 public Profesor() {
		 this.cargo  = "Ninguno";
		 this.antiguedadDocente = 0;
	 }
	 
	 public Profesor (String cargo, int antiguedad , String nombre,int edad) {
		 super(nombre, edad);
		 this.cargo  = cargo;
		 this.antiguedadDocente = antiguedad;
	 }
	 
	 
	 //Getters y Setters
	 public String getCargo() {
		return cargo;
	 }
	 public void setCargo(String cargo) {
		this.cargo = cargo;
	 }
	 public int getAntiguedadDocente() {
		return antiguedadDocente;
	 }
	 public void setAntiguedadDocente(int antiguedadDocente) {
		this.antiguedadDocente = antiguedadDocente;
	 }

	 //toString
	@Override
	 public String toString() {
		return super.toString() + ", CARGO: " + cargo + ", ANTIGUEDAD:" + antiguedadDocente ;
	 }

	//CompareTo
	@Override
	public int compareTo(Profesor o) {
		// Ordenamiento de edad profesores
		
		if(o.getEdad() == this.getEdad())
			return 0;
		if (o.getEdad() < this.getEdad()){
			return 1;
		}
		return -1;
	}

	//Equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Profesor other = (Profesor) obj;
		if (antiguedadDocente != other.antiguedadDocente)
			return false;
		if (cargo == null) {
			if (other.cargo != null)
				return false;
		} else if (!cargo.equals(other.cargo))
			return false;
		return true;
	}

	
}
