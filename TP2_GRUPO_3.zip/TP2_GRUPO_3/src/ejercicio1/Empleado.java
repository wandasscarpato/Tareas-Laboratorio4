package ejercicio1;

public class Empleado {
		//Atributos
		private int id;
		private String nombre;
		private int edad;
		
		static int cant= 999;
		
		//Contructores
		public Empleado() {
			
			  cant++;
			  this.id = cant;
			  this.nombre = "Sin nombre";
			  this.edad = 99;
			}
		
		public Empleado(String nombre,int edad) {
			
			cant++;
			this.id = cant;
			this.nombre = nombre;
			this.edad = edad;  
		}
		
		//METODOS
		
		public static int devuelveProxId()
		{
			return cant+1;
			
		}
		
		//getters setters
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public int getEdad() {
			return edad;
		}
		public void setEdad(int edad) {
			this.edad = edad;
		}

		//ToString()
		@Override
		public String toString() {
			return " EMPLEADO: " + nombre + ", EDAD: " + edad + ", LEGAJO: " + id ;
		}

		//Equals
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Empleado other = (Empleado) obj;
			if (edad != other.edad)
				return false;
			if (nombre == null) {
				if (other.nombre != null)
					return false;
			} else if (!nombre.equals(other.nombre))
				return false;
			return true;
		}
		
}
