package dao;

import java.util.ArrayList;
import entidad.n_prestamo;

public class prestamosDao {

	public ArrayList<n_prestamo> listarPrestamos() {
		return null;
	}
}
