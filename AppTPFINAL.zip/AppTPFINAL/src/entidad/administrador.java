package entidad;

public class administrador {

}
