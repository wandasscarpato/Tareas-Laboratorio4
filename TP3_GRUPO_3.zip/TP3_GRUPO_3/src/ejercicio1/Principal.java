package ejercicio1;

public class Principal {

	public static void main(String[] args) {
		/*	
		try {
			String dni= JOptionPane.showInputDialog("Ingrese DNI: ");
			Persona.validarDni(dni);
		} 
		catch (DniInvalido e) {
			System.out.println("Error ingrese solo caracteres numericos ");
			e.printStackTrace();	
		}
		
		
		Persona persona = new Persona();
		persona.setRuta("Personas.txt");
		persona.leer();*/
		Persona persona = new Persona();
		persona.setRuta("Personas.txt");
		persona.leerABC();
	}

}
