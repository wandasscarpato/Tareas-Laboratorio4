package ejercicio1;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Persona {
	private String ruta;
	
	//constructor
	public Persona () {
	}

	public static boolean validarDni (String dni) throws DniInvalido
	{
		try {
			Integer.parseInt(dni);
			return true;
		} 
		catch (NumberFormatException nfe){
			DniInvalido exc1  = new DniInvalido();
			throw exc1;
		}
	}
	
	//getts setts
	public void leer (){
		
		List<Integer> listaHashes = new ArrayList<>();
		List<String> listaRegistrosSinRepetir = new ArrayList<>();
		FileReader entrada;
		
		try{
			
			entrada= new FileReader(ruta);
			BufferedReader miBuffer = new BufferedReader(entrada);
			String linea=miBuffer.readLine();
			
			while(linea != null){
				
				////CALCULO EL HASH DE LA LINEA
				int hashDeLaLineaActual = linea.hashCode();
				
				////WHILE CONTENEDOR DE HASHES, COMPRUEBA QUE NO EXISTA
				if(listaHashes.size() == 0) {
					listaHashes.add(hashDeLaLineaActual);
				} else {
						
					if(!(listaHashes.contains(hashDeLaLineaActual))) {
					
						listaHashes.add(hashDeLaLineaActual);
						listaRegistrosSinRepetir.add(linea);
						
					}
				}
				//System.out.println(linea);
				linea=miBuffer.readLine();
			}
			
			for(int i=0;i<listaRegistrosSinRepetir.size();i++) {
				System.out.println(listaRegistrosSinRepetir.get(i));
			}
			miBuffer.close();
			entrada.close();
		} catch (IOException e){
			System.out.println("archivo no encontrado");
		}
	}
	
	public void leerABC(){
		
		List<Integer> listaHashes = new ArrayList<>();
		List<String> listaRegistrosSinRepetir = new ArrayList<>();
		FileReader entrada;
		List<String> listaRegistrosPorApellido = new ArrayList<>();
		
		try{
			entrada= new FileReader(ruta);
			BufferedReader miBuffer = new BufferedReader(entrada);
			String linea=miBuffer.readLine();
			
			while(linea != null){	
				////CALCULO EL HASH DE LA LINEA
				int hashDeLaLineaActual = linea.hashCode();
				
				////WHILE CONTENEDOR DE HASHES, COMPRUEBA QUE NO EXISTA
				if(listaHashes.size() == 0) {
					listaHashes.add(hashDeLaLineaActual);
				} else {
						
					if(!(listaHashes.contains(hashDeLaLineaActual) )) {
					
						listaHashes.add(hashDeLaLineaActual);
						listaRegistrosSinRepetir.add(linea);
						
						//Reordeno el archivo
						String[] parts = linea.split("-");
						String nombre = parts[0]; 
						String apellido = parts[1];
						String dni = parts[2];
						
						//Valida que los DNI sean unicamente numeros
						try {
						if(validarDni(dni)) {
							listaRegistrosPorApellido.add(apellido+"-"+ nombre +"-"+ dni);
							System.out.println("Se agrego al usuario: " + apellido + " " + nombre+ " ");
						}
						
						
						}
						catch(Exception e){
							
						}
						
						
					}
				}
				//System.out.println(linea);
				linea=miBuffer.readLine();
			}
			
			for(int i=0;i<listaRegistrosSinRepetir.size();i++) {
				//Ordena Alfabeticamento por Apellido
				Collections.sort(listaRegistrosPorApellido);
				//System.out.println(listaRegistrosPorApellido.get(i));
			}
			
			resultado(listaRegistrosPorApellido);
			
			miBuffer.close();
			entrada.close();
		} catch (IOException e){
			System.out.println("archivo no encontrado");
		}
	}	
	
	
	public void resultado(List<String> l ) {
		
		Archivos ar = new Archivos();
		ar.CrearArchivo("Resultado.txt");
		
		
		ar.EscribirArchivoLista("Resultado.txt", l);
		
		
	}

	public String getRuta() {
		return ruta;
	}

	public void setRuta(String ruta) {
		this.ruta = ruta;
	}
		

}

