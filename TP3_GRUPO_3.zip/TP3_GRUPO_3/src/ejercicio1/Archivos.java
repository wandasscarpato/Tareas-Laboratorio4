package ejercicio1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilterWriter;
import java.io.IOException;
import java.util.List;

public class Archivos {

	private String ruta;
	
	public Archivos() {
		
	}

	public String getRuta() {
		return ruta;
	}

	public void setRuta(String ruta) {
		this.ruta = ruta;
	}
	
	public boolean CrearArchivo(String ruta){
		FileWriter Esc;
		try {
			Esc = new FileWriter(ruta,true);
			Esc.write("");
			Esc.close();
			return true;
		}catch(IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean Existe(String ruta){
		File Archivos = new File(ruta);
		if(Archivos.exists()) {
			return true;
		}
		return false;
	}
/*	
	public void Escribir_Lineas(String frace){
		try {
			FileWriter Entra = new FileWriter("TP3_GRUPO_X//Personas.txt", true);
			BufferedWriter mibuffer = new BufferedWriter(Entra);
			mibuffer.write(frace);
			mibuffer.close();
			Entra.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	*/
	
	public void EscribirArchivo(String ruta, String texto){
		try {
			FileWriter Entra = new FileWriter(ruta, true);
			BufferedWriter mibuffer = new BufferedWriter(Entra);
			mibuffer.write(texto);
			mibuffer.close();
			Entra.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void EscribirArchivoLista(String ruta, List<String> lista){
		try {
			FileWriter Entra = new FileWriter(ruta, false);
			BufferedWriter mibuffer = new BufferedWriter(Entra);
			String aux;
			
			for(int i=0;i<lista.size();i++) {
				
				aux=lista.get(i);
				mibuffer.write(aux + "\n");
				
			}
			
			mibuffer.close();
			Entra.close();
			
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}
	
}
