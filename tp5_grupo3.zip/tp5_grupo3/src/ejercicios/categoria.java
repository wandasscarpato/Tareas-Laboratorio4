package ejercicios;

public class categoria {
	
	private String categoria;
	
	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public categoria() {
	
	}
	
}
